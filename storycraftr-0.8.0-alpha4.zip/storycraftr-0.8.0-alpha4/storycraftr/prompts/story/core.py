FORMAT_OUTPUT = """
Write the book on lang "{language}".
Return in markdown format, without using code block syntax (no triple backticks or code fences).
Do not add your comments ath thend.
You are {reference_author} writing a new engaging book.
"""
